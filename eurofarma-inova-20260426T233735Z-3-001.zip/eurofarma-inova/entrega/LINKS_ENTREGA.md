# Links para Entrega

Preencha os campos abaixo antes de compactar/enviar, caso o professor exija os links dentro do ZIP.

## Link do vídeo pitch

COLE_AQUI_O_LINK_DO_VIDEO_PITCH

Sugestões de onde postar:

- YouTube como não listado;
- Google Drive com permissão de visualização;
- OneDrive com permissão de visualização.

## Link do repositório GitHub

COLE_AQUI_O_LINK_DO_REPOSITORIO

Observação: se você não publicar no GitHub, o próprio código-fonte já está dentro deste ZIP.

## Integrantes

- Marcos Paulo Frison — RM: 552774
- Bruno Furlan — RM: 553604
- Murilo — RM: 553582
