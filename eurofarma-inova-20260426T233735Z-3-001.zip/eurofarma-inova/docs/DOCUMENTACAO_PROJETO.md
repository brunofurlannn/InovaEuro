# Documentação do Projeto — InovaEuro

## 1. Nome da solução

**InovaEuro — Plataforma Inteligente de Engajamento em Inovação**

## 2. Problema

O problema central é a baixa adesão dos colaboradores aos programas de inovação. Em empresas grandes, muitos colaboradores têm ideias, mas não sabem onde registrar, não recebem retorno, não visualizam reconhecimento e acabam deixando de participar.

## 3. Proposta da aplicação

A aplicação resolve esse problema por meio de uma plataforma web responsiva, com navegação simples, cadastro de ideias, gamificação, microlearning e assistente virtual. O objetivo é tornar a participação em inovação mais fácil, acessível e motivadora.

## 4. Público-alvo

- Colaboradores administrativos.
- Colaboradores técnicos.
- Equipes de P&D.
- Colaboradores do chão de fábrica.
- Gestores de programas de inovação.

## 5. Requisitos principais

### Requisitos funcionais

| Código | Requisito | Descrição |
|---|---|---|
| RF01 | Cadastro de ideias | O usuário deve conseguir cadastrar uma ideia com título, área e descrição. |
| RF02 | Listagem de ideias | O sistema deve exibir as ideias cadastradas. |
| RF03 | Filtro de ideias | O usuário deve conseguir buscar ideias por texto e filtrar por status. |
| RF04 | Votação | O usuário deve conseguir votar em ideias. |
| RF05 | Gamificação | O sistema deve calcular pontos por envio de ideia, voto e trilha concluída. |
| RF06 | Ranking | O sistema deve exibir ranking dos colaboradores. |
| RF07 | Microlearning | O sistema deve apresentar uma trilha curta com quiz. |
| RF08 | Assistente virtual | O sistema deve responder dúvidas frequentes sobre o programa. |
| RF09 | Dashboard | O sistema deve exibir indicadores de ideias, votos, trilhas e badges. |

### Requisitos não funcionais

| Código | Requisito | Descrição |
|---|---|---|
| RNF01 | Responsividade | A interface deve funcionar em desktop e celular. |
| RNF02 | Usabilidade | A navegação deve ser clara e consistente. |
| RNF03 | Persistência local | Os dados devem ser salvos localmente no navegador. |
| RNF04 | Organização técnica | O projeto deve separar estrutura, estilo e regra de negócio. |
| RNF05 | Feedback ao usuário | O sistema deve exibir mensagens após ações importantes. |

## 6. Tecnologias utilizadas

- **HTML5:** estrutura das telas.
- **CSS3:** responsividade, layout e identidade visual.
- **JavaScript:** regras de negócio, navegação, cadastro, votação e chatbot.
- **LocalStorage:** persistência local das ideias, votos, pontos e progresso.

## 7. Arquitetura da solução

### Diagrama simples

```text
+---------------------------------------------------+
|                    Usuário                         |
| Colaborador / Gestor / Equipe de inovação          |
+--------------------------+------------------------+
                           |
                           v
+---------------------------------------------------+
|              Interface Web Responsiva              |
| Dashboard | Ideias | Desafios | Ranking | Chatbot  |
+--------------------------+------------------------+
                           |
                           v
+---------------------------------------------------+
|             Camada de Lógica JavaScript            |
| Navegação | Regras de pontos | Filtros | Chatbot   |
+--------------------------+------------------------+
                           |
                           v
+---------------------------------------------------+
|                 Persistência Local                 |
| LocalStorage: ideias, votos, pontuação e progresso |
+---------------------------------------------------+
```

## 8. Estrutura em camadas/componentes

```text
index.html
Camada de apresentação: estrutura das telas e componentes visuais.

src/styles.css
Camada visual: layout, cores, responsividade, cards, modal e feedbacks.

src/app.js
Camada de lógica: navegação, cadastro de ideias, votação, ranking, quiz, chatbot e persistência.

localStorage
Camada de dados: armazenamento local das informações do usuário e das ideias.
```

## 9. Principais telas

### Dashboard

Mostra pontuação do usuário, total de ideias, votos, trilhas concluídas e badges.

### Ideias

Permite visualizar, buscar, filtrar e votar em ideias. Também recebe novas ideias cadastradas pelo modal.

### Desafios

Exibe campanhas de inovação para incentivar participação em temas estratégicos.

### Microlearning

Apresenta uma trilha rápida e um quiz para capacitação contínua.

### Ranking

Mostra a classificação dos colaboradores por pontuação.

### Assistente IA

Simula um assistente virtual que responde dúvidas frequentes sobre envio de ideias, pontos, participação e recompensas.

## 10. Persistência de dados

A persistência foi implementada com `localStorage`, permitindo que as ações do usuário permaneçam salvas mesmo após atualizar a página. São armazenados:

- ideias cadastradas;
- votos realizados;
- pontuação do usuário;
- badges conquistadas;
- trilhas concluídas.

## 11. Critérios de avaliação atendidos

| Critério | Como o projeto atende |
|---|---|
| Clareza do problema e proposta | O projeto apresenta o problema de baixa adesão e propõe uma plataforma de engajamento. |
| Demonstração funcional | A aplicação permite navegação, cadastro, votação, quiz, ranking e chatbot. |
| Experiência do usuário | Layout responsivo, legível, organizado e com feedback por toast. |
| Estrutura técnica | Separação entre HTML, CSS, JavaScript e persistência local. |
| Documentação e apresentação | README, documentação, casos de uso, checklist e roteiro de pitch. |

## 12. Possíveis melhorias futuras

- Integração com banco de dados real.
- Login por colaborador.
- Dashboard administrativo para gestores.
- API real de IA generativa para o assistente.
- Integração com sistemas internos de RH.
- Integração com totens físicos nas unidades.
