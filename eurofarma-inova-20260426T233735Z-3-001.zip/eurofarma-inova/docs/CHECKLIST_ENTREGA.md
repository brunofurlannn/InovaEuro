# Checklist de Entrega — Critérios do Professor

## Arquivo .ZIP deve conter

- [x] Código-fonte da aplicação.
- [x] README com instruções para rodar o projeto.
- [x] Documentação mínima obrigatória.
- [x] Arquivo para inserir link do vídeo pitch.
- [x] Arquivo para inserir link do repositório, caso seja usado GitHub.

## Documentação mínima obrigatória

- [x] Requisitos principais.
- [x] Arquitetura da solução com diagrama simples.
- [x] Tecnologias utilizadas.
- [x] Casos de uso principais.

## Critérios de avaliação

### 1. Clareza do problema e proposta — 1 ponto

- [x] Problema resolvido descrito.
- [x] Público-alvo descrito.
- [x] Objetivo da aplicação descrito.

### 2. Demonstração funcional — 4 pontos

- [x] Aplicação executando.
- [x] Navegação entre telas.
- [x] Interação com usuário.
- [x] Funcionalidade principal implementada: cadastro de ideias.
- [x] Funcionalidades complementares: votação, ranking, microlearning e chatbot.

### 3. Experiência do usuário — 2 pontos

- [x] Organização visual.
- [x] Legibilidade.
- [x] Consistência de navegação.
- [x] Feedback das ações do usuário.
- [x] Layout responsivo.

### 4. Estrutura técnica — 2 pontos

- [x] Separação em HTML, CSS e JavaScript.
- [x] Organização por componentes visuais e funções.
- [x] Separação de responsabilidades.
- [x] Persistência local usando localStorage.

### 5. Documentação e apresentação — 1 ponto

- [x] Artefatos mínimos incluídos.
- [x] Roteiro do vídeo pitch incluso.
- [ ] Link final do vídeo preenchido pelo aluno após gravação.
- [ ] Link final do repositório preenchido pelo aluno, caso publique no GitHub.
