# Roteiro do Vídeo Pitch — até 5 minutos

## Tempo sugerido: 4min30s a 5min

### 0:00 a 0:35 — Apresentação do problema

Olá, meu nome é Marcos Paulo Frison e este projeto foi desenvolvido para o Challenge Eurofarma.  
O problema que a aplicação resolve é a baixa adesão dos colaboradores aos programas de inovação. Em empresas grandes, muitos colaboradores têm boas ideias, mas não sabem onde registrar, não recebem retorno e acabam não participando.  
A proposta do InovaEuro é tornar esse processo mais simples, acessível e motivador.

### 0:35 a 1:10 — Público-alvo e proposta

O público-alvo são colaboradores administrativos, técnicos, equipes de P&D e também colaboradores do chão de fábrica.  
A aplicação centraliza envio de ideias, desafios, microlearning, ranking, recompensas e um assistente virtual para dúvidas frequentes.  
O objetivo é aumentar o engajamento e fazer com que o colaborador seja protagonista da inovação.

### 1:10 a 1:50 — Arquitetura e estrutura do projeto

A arquitetura é simples e organizada em camadas.  
A camada de apresentação está no arquivo `index.html`, responsável pela estrutura das telas.  
A camada visual está em `src/styles.css`, com layout responsivo, cards, modal, ranking e chatbot.  
A camada de lógica está em `src/app.js`, onde ficam navegação, cadastro de ideias, votação, pontuação, quiz e assistente virtual.  
A persistência de dados é local, usando `localStorage`, salvando ideias, votos, pontos e trilhas concluídas.

### 1:50 a 3:50 — Demonstração funcional

Agora vou demonstrar a aplicação em funcionamento.  
Na tela inicial, temos o dashboard com pontuação do colaborador, quantidade de ideias cadastradas, votos recebidos, trilhas concluídas e badges.  
Ao clicar em `+ Enviar ideia`, o usuário informa título, área e descrição da ideia. Depois de salvar, a ideia aparece automaticamente no banco de ideias e o colaborador ganha pontos.  
Na tela de ideias, é possível buscar, filtrar por status e votar em ideias. Ao votar, o sistema atualiza a quantidade de votos e adiciona pontos de participação.  
Na tela de desafios, a aplicação mostra campanhas de inovação, incentivando ideias por tema.  
No microlearning, o colaborador acessa uma trilha rápida e responde um quiz. Ao acertar, recebe pontos e uma badge.  
No ranking, é possível acompanhar a classificação dos colaboradores por pontuação.  
Por fim, temos o assistente virtual, que simula uma IA para responder perguntas como: como enviar uma ideia, como ganhar pontos e quem pode participar.

### 3:50 a 4:30 — UX e diferenciais

A experiência do usuário foi pensada para ser simples, visual e consistente.  
O menu lateral facilita a navegação, os cards organizam as informações, os botões são claros e o sistema exibe feedback quando o usuário cadastra uma ideia, vota ou conclui uma trilha.  
A interface também é responsiva, funcionando em telas menores, o que atende à proposta de acessibilidade multicanal.

### 4:30 a 5:00 — Encerramento

Concluindo, o InovaEuro atende ao desafio ao unir engajamento, gamificação, microlearning e assistente virtual em uma única solução.  
A aplicação possui pelo menos uma funcionalidade principal implementada, navegação entre telas, interação com o usuário, persistência local e documentação para execução do projeto.  
Obrigado.

---

## Checklist para gravação

- Mostrar o dashboard inicial.
- Mostrar a estrutura de pastas no VS Code.
- Abrir `index.html`, `src/styles.css` e `src/app.js` rapidamente.
- Cadastrar uma nova ideia.
- Votar em uma ideia.
- Concluir o quiz de microlearning.
- Mostrar o ranking atualizado.
- Fazer uma pergunta no assistente virtual.
- Não ultrapassar 5 minutos.
