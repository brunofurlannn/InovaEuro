# Casos de Uso Principais — InovaEuro

## Caso de Uso 01 — Enviar ideia

**Ator:** Colaborador  
**Objetivo:** Registrar uma ideia de melhoria no programa de inovação.

### Fluxo principal

1. O colaborador acessa a aplicação.
2. Clica em `+ Enviar ideia`.
3. Informa título, área e descrição.
4. Clica em salvar.
5. O sistema registra a ideia com status `Nova`.
6. O sistema adiciona pontos ao colaborador.
7. O sistema exibe mensagem de sucesso.

### Resultado esperado

A ideia aparece na tela de ideias e a pontuação do usuário é atualizada.

---

## Caso de Uso 02 — Votar em ideia

**Ator:** Colaborador  
**Objetivo:** Apoiar ideias de outros colaboradores.

### Fluxo principal

1. O colaborador acessa a tela `Ideias`.
2. Busca ou filtra as ideias disponíveis.
3. Clica em `Votar`.
4. O sistema registra o voto.
5. O sistema adiciona pontos de participação.
6. O botão passa a mostrar `Votado`.

### Resultado esperado

A quantidade de votos aumenta e o colaborador recebe pontos.

---

## Caso de Uso 03 — Concluir microlearning

**Ator:** Colaborador  
**Objetivo:** Aprender conceitos de inovação de forma rápida.

### Fluxo principal

1. O colaborador acessa `Microlearning`.
2. Lê a trilha rápida.
3. Responde ao quiz.
4. Se a resposta estiver correta, o sistema conclui a trilha.
5. O sistema adiciona pontos e badge.

### Resultado esperado

A trilha é contabilizada no dashboard e o ranking é atualizado.

---

## Caso de Uso 04 — Consultar assistente virtual

**Ator:** Colaborador  
**Objetivo:** Tirar dúvidas sobre o programa de inovação.

### Fluxo principal

1. O colaborador acessa `Assistente IA`.
2. Digita uma pergunta ou clica em uma pergunta sugerida.
3. O sistema interpreta a pergunta.
4. O sistema retorna uma resposta sobre envio de ideias, pontos, participação ou recompensas.

### Resultado esperado

O colaborador recebe orientação clara e rápida.

---

## Caso de Uso 05 — Acompanhar ranking

**Ator:** Colaborador ou gestor  
**Objetivo:** Visualizar os participantes mais engajados.

### Fluxo principal

1. O usuário acessa `Ranking`.
2. O sistema exibe a lista de colaboradores por pontuação.
3. O usuário visualiza recompensas disponíveis.

### Resultado esperado

O ranking motiva a participação e reforça a gamificação.
